package practica3;

public class i {

}
